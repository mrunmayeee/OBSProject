package com.cg.banking.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.banking.dto.Transaction_dto;
import com.cg.banking.dto.User_dto;
import com.cg.banking.exception.BankingException;
import com.cg.banking.service.IUserService;
import com.cg.banking.service.UserServiceImpl;

public class Client {

	public static void main(String[] args) {
		
		IUserService service = new UserServiceImpl();
		Scanner sc = new Scanner(System.in);
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date from=null;
		Date to=null;
		int choice=0;
		User_dto user = new User_dto();
		System.out.println("****LOGIN PAGE FOR USER****");
		System.out.println("User ID: ");
		int user_id = sc.nextInt();
		user.setUser_id(user_id);
		System.out.println("Password: ");
		String pass = sc.next();
		user.setLogin_password(pass);
		try {
			if(service.verifyUser(user_id, pass)){
				do{
					printDetails();
					System.out.println("Please enter a choice: ");
					choice = sc.nextInt();
					switch(choice){
					case 1:
						System.out.println("Mini-Detailed Statement");
						List<Transaction_dto> miniDetail = new ArrayList<Transaction_dto>();
						miniDetail = service.miniDetailList(user_id);
						//for(int i=0;i<=10;i++){
							System.out.println(miniDetail);
						//}
						System.out.println("Detailed Statement");
						List<Transaction_dto> detail = new ArrayList<Transaction_dto>();
						System.out.println("Enter the start and end date:(MM/dd/yyyy) ");
						String f = sc.next();
						String t=sc.next();
						try {
							from= sdf.parse(f);
							to = sdf.parse(t);
						} catch (ParseException e) {
							System.out.println("Invalid format");
							e.printStackTrace();
						}
						if(!sdf.format(from).equals(f)){
							System.out.println("Invalid date");
						}
						else{
							System.out.println("Valid date");
						}
						detail=service.detailedStmt(user_id, from, to);
						System.out.println(detail);
						
						break;
						
					case 2: //change in addr and mobile no
						System.out.println("Please select an option:");
						int ch=sc.nextInt();
						switch (ch) {
						case 1: //change in address
							String addr = service.getAddress(user_id);
							System.out.println("Old Address:"+addr);
							System.out.println("Edit Address: ");
							String newAddr = sc.next();
							if(service.updateAddr(newAddr,user_id)){
								System.out.println("Successfully Updated");
							}
							
							break;

						case 2: //change in mobile no
							int mobileNo = service.getMobileNo(user_id);
							System.out.println("Old Mobile No:"+mobileNo);
							System.out.println("Edit Mobile No");
							int newMobNo=sc.nextInt();
							if(service.updateMobileNo(newMobNo,user_id)){
								System.out.println("Successfully updated");
							}
							break;
						}
						
					case 3: //request for cheque book
						System.out.println("Do you want to place the request for cheque book? Yes or No");
						int choice3=sc.nextInt();
						switch (choice3) {
						case 1://if yes
							int service_req_no= service.generateServiceReqNo(user_id);
							System.out.println("Your service request number is:"+service_req_no);
							break;

						case 2:System.out.println("Thank you");
							break;
						}
						

						
					case 4://track service request
						String status = service.showServiceStatus(user_id);
						System.out.println("Status: "+status);
						
					case 5: //fund transfer
						System.out.println("Please select an option:");
						int ch1=sc.nextInt();
						switch (ch1) {
						
						case 1: //Transfer to your own account
							
						
						}
					}
				}
				while(choice!=8);
				
			}
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void printDetails() {
		System.out.println("***********************");
		System.out.println("1. View Mini/Detailed Statement");
		System.out.println("2. Change in Address/Mobile Number");
		System.out.println("3. Request for Cheque book");
		System.out.println("4. Track Service Request");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Change Password");
		System.out.println("0. Exit");
		
	}

}
