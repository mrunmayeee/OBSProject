package com.cg.banking.exception;

public class BankingException extends Exception{

	public BankingException() {
	super();
	}
	
	public BankingException(String msg){
		super(msg);
	}

}
