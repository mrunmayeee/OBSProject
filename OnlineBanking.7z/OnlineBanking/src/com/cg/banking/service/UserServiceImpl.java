package com.cg.banking.service;

import java.util.Date;
import java.util.List;

import com.cg.banking.dao.IUserDao;
import com.cg.banking.dao.UserDaoImpl;
import com.cg.banking.dto.Transaction_dto;
import com.cg.banking.exception.BankingException;



public class UserServiceImpl implements IUserService {

	IUserDao dao;
	
	public UserServiceImpl() {
		dao = new UserDaoImpl();
	}

	@Override
	public boolean verifyUser(int user_id, String login_password)
			throws BankingException {
		
		return dao.verifyUser(user_id, login_password);
	}

	@Override
	public List<Transaction_dto> miniDetailList(int user_id)
			throws BankingException {
		// TODO Auto-generated method stub
		return dao.miniDetailList(user_id);
	}

	@Override
	public List<Transaction_dto> detailedStmt(int user_id, Date from, Date to)
			throws BankingException {
		// TODO Auto-generated method stub
		return dao.detailedStmt(user_id, from, to);
	}
	
	public String getAddress(int user_id) throws BankingException{
		return dao.getAddress(user_id);
	}

	@Override
	public boolean updateAddr(String newAddr, int user_id)
			throws BankingException {
		// TODO Auto-generated method stub
		return dao.updateAddr(newAddr, user_id);
	}

	@Override
	public int getMobileNo(int user_id) throws BankingException {
		// TODO Auto-generated method stub
		return dao.getMobileNo(user_id);
	}

	@Override
	public boolean updateMobileNo(int newMobNo, int user_id)
			throws BankingException {
		// TODO Auto-generated method stub
		return dao.updateMobileNo(newMobNo, user_id);
	}

	@Override
	public int generateServiceReqNo(int user_id) throws BankingException {
		
		return dao.generateServiceReqNo(user_id);
	}

	@Override
	public String showServiceStatus(int user_id) throws BankingException {
		// TODO Auto-generated method stub
		return dao.showServiceStatus(user_id);
	}
	

}
