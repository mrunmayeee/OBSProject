package com.cg.banking.dto;

import java.util.Date;

public class FundTransfer_dto {

	private int fundTransfer_id;
	private int account_id;
	private int payee_account_id;
	private Date date_of_transfer;
	private int trans_amount;
	
	public FundTransfer_dto() {
		super();
	}

	public FundTransfer_dto(int fundTransfer_id, int account_id,
			int payee_account_id, Date date_of_transfer, int trans_amount) {
		super();
		this.fundTransfer_id = fundTransfer_id;
		this.account_id = account_id;
		this.payee_account_id = payee_account_id;
		this.date_of_transfer = date_of_transfer;
		this.trans_amount = trans_amount;
	}

	public int getFundTransfer_id() {
		return fundTransfer_id;
	}

	public void setFundTransfer_id(int fundTransfer_id) {
		this.fundTransfer_id = fundTransfer_id;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

	public int getPayee_account_id() {
		return payee_account_id;
	}

	public void setPayee_account_id(int payee_account_id) {
		this.payee_account_id = payee_account_id;
	}

	public Date getDate_of_transfer() {
		return date_of_transfer;
	}

	public void setDate_of_transfer(Date date_of_transfer) {
		this.date_of_transfer = date_of_transfer;
	}

	public int getTrans_amount() {
		return trans_amount;
	}

	public void setTrans_amount(int trans_amount) {
		this.trans_amount = trans_amount;
	}

	public String toString() {
		return "FundTransfer_dto [fundTransfer_id=" + fundTransfer_id
				+ ", account_id=" + account_id + ", payee_account_id="
				+ payee_account_id + ", date_of_transfer=" + date_of_transfer
				+ ", trans_amount=" + trans_amount + "]";
	}

	
	
}
