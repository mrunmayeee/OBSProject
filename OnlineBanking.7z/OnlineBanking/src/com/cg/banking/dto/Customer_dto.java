package com.cg.banking.dto;

public class Customer_dto {

	private int account_id;
	private String cust_name;
	private String email;
	private String address;
	private String pancard;
	public Customer_dto() {
		super();
	}
	public Customer_dto(int account_id, String cust_name, String email,
			String address, String pancard) {
		super();
		this.account_id = account_id;
		this.cust_name = cust_name;
		this.email = email;
		this.address = address;
		this.pancard = pancard;
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String toString() {
		return "Customer_Dto [account_id=" + account_id + ", cust_name="
				+ cust_name + ", email=" + email + ", address=" + address
				+ ", pancard=" + pancard + "]";
	}
	



	
}
