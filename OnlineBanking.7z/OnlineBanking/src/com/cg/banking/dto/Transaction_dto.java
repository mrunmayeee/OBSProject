package com.cg.banking.dto;

import java.util.Date;

public class Transaction_dto {

	private int trans_id;
	private String trans_desp;
	private Date trans_date;
	private String trans_type;
	private int trans_amt;
	private int account_no;
	public Transaction_dto() {
		super();
	}
	public Transaction_dto(int trans_id, String trans_desp, Date trans_date,
			String trans_type, int trans_amt, int account_no) {
		super();
		this.trans_id = trans_id;
		this.trans_desp = trans_desp;
		this.trans_date = trans_date;
		this.trans_type = trans_type;
		this.trans_amt = trans_amt;
		this.account_no = account_no;
	}
	public int getTrans_id() {
		return trans_id;
	}
	public void setTrans_id(int trans_id) {
		this.trans_id = trans_id;
	}
	public String getTrans_desp() {
		return trans_desp;
	}
	public void setTrans_desp(String trans_desp) {
		this.trans_desp = trans_desp;
	}
	public Date getTrans_date() {
		return trans_date;
	}
	public void setTrans_date(Date trans_date) {
		this.trans_date = trans_date;
	}
	public String getTrans_type() {
		return trans_type;
	}
	public void setTrans_type(String trans_type) {
		this.trans_type = trans_type;
	}
	public int getTrans_amt() {
		return trans_amt;
	}
	public void setTrans_amt(int trans_amt) {
		this.trans_amt = trans_amt;
	}
	public int getAccount_no() {
		return account_no;
	}
	public void setAccount_no(int account_no) {
		this.account_no = account_no;
	}
	public String toString() {
		return "Transaction_Dto [trans_id=" + trans_id + ", trans_desp="
				+ trans_desp + ", trans_date=" + trans_date + ", trans_type="
				+ trans_type + ", trans_amt=" + trans_amt + ", account_no="
				+ account_no + "]";
	}
	
	
	
}
