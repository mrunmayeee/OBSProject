package com.cg.banking.dto;

import java.util.Date;

public class Account_dto {

	private int account_id;
	private String account_type;
	private int account_balance;
	private Date open_date;
	public Account_dto() {
		super();
	}
	public Account_dto(int account_id, String account_type,
			int account_balance, Date open_date) {
		super();
		this.account_id = account_id;
		this.account_type = account_type;
		this.account_balance = account_balance;
		this.open_date = open_date;
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public int getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(int account_balance) {
		this.account_balance = account_balance;
	}
	public Date getOpen_date() {
		return open_date;
	}
	public void setOpen_date(Date open_date) {
		this.open_date = open_date;
	}
	public String toString() {
		return "Account_Dto [account_id=" + account_id + ", account_type="
				+ account_type + ", account_balance=" + account_balance
				+ ", open_date=" + open_date + "]";
	}
	

	
	
}
