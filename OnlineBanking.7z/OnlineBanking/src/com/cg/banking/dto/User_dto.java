package com.cg.banking.dto;

public class User_dto {

	private int account_id;
	private int user_id;
	private String login_password;
	private String secret_question;
	private String trans_password;
	private String lock_status;
	
	public User_dto() {
		super();
	}

	public User_dto(int account_id, int user_id, String login_password,
			String secret_question, String trans_password, String lock_status) {
		super();
		this.account_id = account_id;
		this.user_id = user_id;
		this.login_password = login_password;
		this.secret_question = secret_question;
		this.trans_password = trans_password;
		this.lock_status = lock_status;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getLogin_password() {
		return login_password;
	}

	public void setLogin_password(String login_password) {
		this.login_password = login_password;
	}

	public String getSecret_question() {
		return secret_question;
	}

	public void setSecret_question(String secret_question) {
		this.secret_question = secret_question;
	}

	public String getTrans_password() {
		return trans_password;
	}

	public void setTrans_password(String trans_password) {
		this.trans_password = trans_password;
	}

	public String getLock_status() {
		return lock_status;
	}

	public void setLock_status(String lock_status) {
		this.lock_status = lock_status;
	}

	public String toString() {
		return "User_dto [account_id=" + account_id + ", user_id=" + user_id
				+ ", login_password=" + login_password + ", secret_question="
				+ secret_question + ", trans_password=" + trans_password
				+ ", lock_status=" + lock_status + "]";
	}

}
