package com.cg.banking.dto;

import java.util.Date;

public class ServiceTracker_dto {

	private int service_id;
	private String service_desp;
	private int account_id;
	private Date service_raised_date;
	private String service_status;
	
	
	
	public ServiceTracker_dto() {
		super();
	}



	public ServiceTracker_dto(int service_id, String service_desp,
			int account_id, Date service_raised_date, String service_status) {
		super();
		this.service_id = service_id;
		this.service_desp = service_desp;
		this.account_id = account_id;
		this.service_raised_date = service_raised_date;
		this.service_status = service_status;
	}



	public int getService_id() {
		return service_id;
	}



	public void setService_id(int service_id) {
		this.service_id = service_id;
	}



	public String getService_desp() {
		return service_desp;
	}



	public void setService_desp(String service_desp) {
		this.service_desp = service_desp;
	}



	public int getAccount_id() {
		return account_id;
	}



	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}



	public Date getService_raised_date() {
		return service_raised_date;
	}



	public void setService_raised_date(Date service_raised_date) {
		this.service_raised_date = service_raised_date;
	}



	public String getService_status() {
		return service_status;
	}



	public void setService_status(String service_status) {
		this.service_status = service_status;
	}



	public String toString() {
		return "ServiceTracker_dto [service_id=" + service_id
				+ ", service_desp=" + service_desp + ", account_id="
				+ account_id + ", service_raised_date=" + service_raised_date
				+ ", service_status=" + service_status + "]";
	}

	
}
