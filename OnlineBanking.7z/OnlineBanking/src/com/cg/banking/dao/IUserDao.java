package com.cg.banking.dao;

import java.util.Date;
import java.util.List;

import com.cg.banking.dto.Transaction_dto;
import com.cg.banking.exception.BankingException;

public interface IUserDao {

	boolean verifyUser(int user_id,String login_password) throws BankingException;
	List<Transaction_dto> miniDetailList(int user_id) throws BankingException;
	List<Transaction_dto> detailedStmt(int user_id,Date from,Date to) throws BankingException;
	String getAddress(int user_id) throws BankingException;
	boolean updateAddr(String newAddr,int user_id) throws BankingException;
	int getMobileNo(int user_id) throws BankingException;
	boolean updateMobileNo(int newMobNo,int user_id) throws BankingException;
	public int generateServiceReqNo(int user_id)throws BankingException;
	public String showServiceStatus(int user_id)throws BankingException;
	
}
