package com.cg.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;








import com.cg.banking.dto.Customer_dto;
import com.cg.banking.dto.Transaction_dto;
import com.cg.banking.exception.BankingException;
import com.cg.banking.util.JdbcUtil;

public class UserDaoImpl implements IUserDao {

	public boolean verifyUser(int user_id, String login_password)
			throws BankingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int rec = 0;
		String query = "select user_id,login_password from UserTable where user_id=?";

		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, user_id);
			rs = ps.executeQuery();
			if (rs.next()) {

				return true;
			}

		} catch (SQLException e) {

			throw new BankingException("Data not found");
		}
		return false;

	}

	@Override
	public List<Transaction_dto> miniDetailList(int user_id)
			throws BankingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int rec = 0;
		List<Transaction_dto> myList = new ArrayList<Transaction_dto>();
		int acc_no = getAccNo(user_id);
		String query = "select * from Transactions where Account_ID=?";

		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			rs = ps.executeQuery();
			if (rs.next()) {
				Transaction_dto trans = new Transaction_dto();
				trans.setTrans_id(rs.getInt(1));
				trans.setTrans_desp(rs.getString(2));
				trans.setTrans_date(rs.getDate(3));
				trans.setTrans_type(rs.getString(4));
				trans.setTrans_amt(rs.getInt(5));
				trans.setAccount_no(rs.getInt(6));
				myList.add(trans);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return myList;

	}

	public int getAccNo(int user_id) {

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int acc_no = 0;
		String query = "select Account_ID from UserTable where user_id=?";
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, user_id);
			rs = ps.executeQuery();
			if (rs.next()) {
				acc_no = rs.getInt(1);
			}
		} catch (SQLException | BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return acc_no;

	}

	@Override
	public List<Transaction_dto> detailedStmt(int user_id,Date from, Date to)
			throws BankingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int rec = 0;
		List<Transaction_dto> myList = new ArrayList<Transaction_dto>();
		int acc_no = getAccNo(user_id);
		String query = "select * from Transactions where Account_ID=? and DateofTransaction between ? and ?";
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			java.sql.Date dateString =(2, (java.sql.Date) from);
			ps.setDate(2, (java.sql.Date) from);
			ps.setDate(3, (java.sql.Date) to);
			rs = ps.executeQuery();
			if (rs.next()) {
				Transaction_dto trans = new Transaction_dto();
				trans.setTrans_id(rs.getInt(1));
				trans.setTrans_desp(rs.getString(2));
				trans.setTrans_date(rs.getDate(3));
				trans.setTrans_type(rs.getString(4));
				trans.setTrans_amt(rs.getInt(5));
				myList.add(trans);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return myList;
		
	}

	@Override
	public String getAddress(int user_id) throws BankingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String rec = null;
		List<Transaction_dto> myList = new ArrayList<Transaction_dto>();
		int acc_no = getAccNo(user_id);
		String query = "select address from Customer where account_ID=?";  
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			rs = ps.executeQuery();
			if (rs.next()) {
				rec=rs.getString(1);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
		return rec;
	}

	@Override
	public boolean updateAddr(String newAddr, int user_id)
			throws BankingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int acc_no = getAccNo(user_id);
		String query="update Customer set address=? where account_ID=?"; 
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			rs = ps.executeQuery();
			if (rs.next()) {
				return true;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public int getMobileNo(int user_id) throws BankingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int rec = 0;
		int acc_no = getAccNo(user_id);
		String query = "select mobile_no from Customer where account_ID=?";  
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			rs = ps.executeQuery();
			if (rs.next()) {
				rec=rs.getInt(1);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
		return rec;
	}

	@Override
	public boolean updateMobileNo(int newMobNo, int user_id)
			throws BankingException {
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int acc_no = getAccNo(user_id);
		String query="update Customer set mobile_no=? where account_ID=?"; 
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			rs = ps.executeQuery();
			if (rs.next()) {
				return true;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public int generateServiceReqNo(int user_id) throws BankingException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int acc_no = getAccNo(user_id);
		int serv_req=0;
		String query="select service_req_id.nextval from dual";
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			rs = ps.executeQuery();
			if (rs.next()) {
				 serv_req = rs.getInt(1);
				 return serv_req;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public String showServiceStatus(int user_id) throws BankingException {
	
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int acc_no = getAccNo(user_id);
		String serv_status=null;
		String query="select service_status from ServiceTracker where account_Id=?";
		try {
			con = JdbcUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setInt(1, acc_no);
			rs = ps.executeQuery();
			if (rs.next()) {
				serv_status = rs.getString(1);
				 return serv_status;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
